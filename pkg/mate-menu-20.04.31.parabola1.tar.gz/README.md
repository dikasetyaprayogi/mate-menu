
This is the libre fork version of MATE MENU for use with gnu linux libre distribution

  * removed google search integration
  * only recommends libre apps

ORIGINAL NOTICE
---------------
This is MATE Menu, a fork of [MintMenu](https://github.com/linuxmint/mintmenu).

  * MATE Menu removes the Mint specific search options.
  * MATE Menu removes package management features.

Personally I'm not the least bit interested in using the MATE Menu but I 
see that it is regularly requested in the Ubuntu MATE community. So 
consider MATE Menu a gift from me, to you :-)

MATE Menu needs translators!

  * https://www.transifex.com/projects/p/MATE/resource/mate-mate/
